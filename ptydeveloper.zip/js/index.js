/* 
 * En este archivo se guardara la parte dinamica de JS que sea referente al index.
 */
$(function() {
    $( "#dialog" ).dialog();
  });