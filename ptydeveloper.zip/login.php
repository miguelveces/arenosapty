<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
    <html>
        <head>
            <META http-equiv="Content-Type" content="text/html; charset=utf-8">
                 <title>PTY Lotto</title>
        <style>
           a:link{ color:#9eb73a }
           a:visited{color:#9eb73a}
           a:hover{color:#9eb73a}
           a:active{color:#9eb73a}
            
           body
           {
            background-image: url(img/fondo1.jpg)
            
           }
        </style>
        </head>
    <body>

       
           
           
            <table id="Tabla_01"  width="100%"  border="0" cellpadding="0" cellspacing="0">
                <tr>

                    <td background="img/bkg_1.jpg" height="124" height="116" >
                        <div>
                            <div style="float:left;padding-top:12px">  <img src="img/logo.jpg"></div> 
                            <div style="float:right; padding-top:13px">  <img src="img/estrellas.jpg"></div>
                        </div>
                    </td>
                </tr>
                <tr>


                    <td background="img/bkg_2.jpg" height="500" style=" vertical-align: top; padding-top: 35px ">

                        <table  align="center" width="100%" height="500" border="0" cellpadding="0" cellspacing="0">
                            <tr>
                                <td style=" vertical-align: top;">
                                    <form name="frmLogin" action="clases/seguridad/valida_usuario.php" method="POST"> 
                                    <div data-role="fieldcontain" id="login" style="text-align:left; ">
                                        <div style=" margin-left:auto; margin-right:15px;width:313px;  height: 91px;  background-image: url(img/inicio-sesion.jpg); background-repeat: no-repeat; background-size: 313px 91px"></div>
                                        <div style=" margin-left:auto; width:290px;padding-bottom: 6px; margin-top:-15px"><label for="user" style="font-size:12px; font-family: arial; font-weight: bold; color:#666666">Correo electronico</label></div>
                                        <div style=" margin-left:auto; width:290px;padding-bottom: 6px  "><input type="text" name="user" id="user" value="" style="border-right: 1px solid #e6e6e6;border-bottom: 1px solid #e6e6e6;border-left: 1px solid #bfbfbf;border-top: 1px solid #bfbfbf;width: 240px; height: 25px;background-color:#e6e6e6"/></div>
                                        <div style=" margin-left:auto; width:290px;padding-bottom: 6px   "><label for="pwd" style="font-size:12px; font-family: arial; font-weight: bold; color:#666666">Contrase&ntilde;a:</label></div>
                                        <div style=" margin-left:auto; width:290px;padding-bottom: 8px  "><input type="password" name="pass" id="pwd" value="" placeholder="contrase&ntilde;a" style="border-right: 1px solid #e6e6e6;border-bottom: 1px solid #e6e6e6;border-left: 1px solid #bfbfbf;border-top: 1px solid #bfbfbf;width: 240px; height: 25px;background-color:#e6e6e6" />    </div>
                                        <div> <h2 id="error"> </h2></div>
                                        <div style=" margin-left:auto;margin-right:53px;text-align: right; width:290px; padding-bottom: 20px"><input type="image" src="img/btn-inicio.gif"/></div>
                                        <div style=" margin-left:auto;margin-right:50px;text-align: center; width:290px; padding-bottom: 6px"><a href="recupera_pwd.php" style="text-decoration:none; font-family:arial;font-size: 12px; font-weight:bold "> &iquest;Ha olvidado su contrase&ntilde;a?</a></div>
                                    </div>  
                                </form>
                                </td>
                                <td style=" vertical-align: top; ">
                                    <form name="frmRegistro" action="registro_usuario.php" method="POST">
                                    <div data-role="fieldcontain" id="login1" style="text-align:left; ">
                                        <div style="  margin-right: auto; margin-left:15px; width:313px; height: 91px;  background-image: url(img/registrese.jpg); background-repeat: no-repeat; background-size: 313px 91px"></div>
                                        <div style="  margin-right: auto;margin-left:53px; width:290px;padding-bottom: 6px; margin-top:-15px"><label for="user" style="font-size:12px; font-family: arial; font-weight: bold; color:#666666">Ingrese su correo electronico</label></div>
                                        <div style="  margin-right: auto;margin-left:53px; width:290px;padding-bottom: 6px  "><input type="email" name="correo_electronico" style="border-right: 1px solid #e6e6e6;border-bottom: 1px solid #e6e6e6;border-left: 1px solid #bfbfbf;border-top: 1px solid #bfbfbf;width: 240px; height: 25px;background-color:#e6e6e6"/></div>
                                        <div style="  margin-right: auto;margin-left:53px; width:290px;padding-bottom: 6px;height: 19px   "></div>
                                        <div style="  margin-right: auto;margin-left:53px; width:290px;padding-bottom: 8px;height: 25px ">   </div>
                                        <div style="  margin-right: auto; margin-left:53px; width:290px;"> 
                                        <h2 id="error"> </h2></div>
                                        <div style="  margin-right: auto; width:290px;text-align: right;padding-bottom: 6px"><input type="image" src="img/btn-aceptar.gif" data-theme="b" /></div>
                                        </form>
                                        <div></div>
                                    </div>  
                               </td>
                            </tr>
                            <tr>
                                <td colspan="2" style=" vertical-align: bottom;"> 
                                    <div>
                                        <div style="float:right; padding-right:13px">  <img src="img/logo-loteria.gif">
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
            		          
             
                    </td>
                    
                </tr>
                <tr>
                    <td background="img/bkg_3.jpg" height="40" >
                        
                    </td>
                </tr>
             </table>
           
        


    </body>
</html>

